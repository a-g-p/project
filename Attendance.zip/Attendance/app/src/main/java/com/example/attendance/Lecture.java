package com.example.attendance;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Lecture extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText pass;
    Button next;
    EditText name;
   ArrayList<String> addArray;
   EditText date;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lecture);

        Spinner spinner=findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter =ArrayAdapter.createFromResource(this,R.array.Day,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        //* spinner //*
        name=findViewById(R.id.name);
        pass=findViewById(R.id.pass);
        date=findViewById(R.id.date);
        next=findViewById(R.id.Next);

        addArray=new ArrayList<String>();

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check();

            }
        });



    }




    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text=parent.getItemAtPosition(position).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    public void check(){
       if (date.getText().toString().equals("")|| name.getText().toString().equals("")) {
            Toast.makeText(this, "Invalid info", Toast.LENGTH_SHORT).show();
            return;}

        Intent a = new Intent(this,Attendance.class);
        startActivity(a);
        finish();


    }

    @Override
    public void onBackPressed()
    {


        Intent backToMenu = new Intent(this,Doctor.class);
        startActivity(backToMenu);
        finish();
    }





}